package com.jarvis.one

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.PixelFormat
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlin.math.abs

/** Gemini jaisa floating bubble. Tap -> command panel (text ya voice). */
class BubbleOverlay(private val svc: AccessibilityService) {

    private val ctx: Context = ContextThemeWrapper(svc, R.style.Theme_Jarvis)
    private val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val prefs = SecurePrefs(svc)
    private val client = GroqClient(prefs)
    private val type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY

    private var bubble: View? = null
    private var panel: View? = null
    private var recognizer: SpeechRecognizer? = null

    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(svc, s, Toast.LENGTH_SHORT).show()

    fun show() {
        if (bubble != null) return
        val v = ImageView(ctx).apply {
            setImageResource(R.drawable.logo)
            setBackgroundResource(R.drawable.send_bg)
            clipToOutline = true
            elevation = dp(6).toFloat()
            alpha = 0.95f
        }
        val lp = WindowManager.LayoutParams(
            dp(56), dp(56), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = dp(300)
        }

        var sx = 0
        var sy = 0
        var tx = 0f
        var ty = 0f
        var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt()
                    val dy = (e.rawY - ty).toInt()
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    if (moved) {
                        lp.x = sx + dx
                        lp.y = sy + dy
                        wm.updateViewLayout(v, lp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) togglePanel()
                }
            }
            true
        }
        wm.addView(v, lp)
        bubble = v
    }

    private fun togglePanel() {
        if (panel == null) showPanel() else hidePanel()
    }

    private fun showPanel() {
        val v = LayoutInflater.from(ctx).inflate(R.layout.overlay_panel, null)
        val lp = WindowManager.LayoutParams(
            (ctx.resources.displayMetrics.widthPixels * 0.94).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(60)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE or
                WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        }

        val et = v.findViewById<EditText>(R.id.oInput)
        v.findViewById<ImageButton>(R.id.oSend).setOnClickListener { submit(v, et.text.toString()) }
        v.findViewById<ImageButton>(R.id.oMic).setOnClickListener { listen(v) }
        v.findViewById<ImageButton>(R.id.oClose).setOnClickListener { hidePanel() }
        et.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_SEND) { submit(v, et.text.toString()); true } else false
        }

        wm.addView(v, lp)
        panel = v
        et.requestFocus()
    }

    private fun hidePanel() {
        recognizer?.cancel()
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
    }

    private fun submit(v: View, text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        val reply = v.findViewById<TextView>(R.id.oReply)
        v.findViewById<EditText>(R.id.oInput).setText("")
        reply.visibility = View.VISIBLE
        if (prefs.apiKey.isBlank()) {
            reply.text = "⚙ Pehle Jarvis1 app ki Settings mein API key daalo."
            return
        }
        reply.text = "…"
        scope.launch {
            try {
                val raw = client.chat(t)
                val (clean, action) = ActionParser.parse(raw)
                reply.text = clean.ifBlank { "Ho gaya." }
                if (action != null) {
                    hidePanel()
                    toast(Actions.run(svc, action))
                }
            } catch (e: Exception) {
                reply.text = "⚠ ${e.message}"
            }
        }
    }

    private fun listen(v: View) {
        if (ContextCompat.checkSelfPermission(svc, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            toast("Mic permission do: Jarvis1 app kholo aur Allow karo")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(svc)) {
            toast("Voice recognition available nahi")
            return
        }
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(svc)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { toast("🎤 Boliye...") }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { toast("Samajh nahi aaya, dobara bolo") }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onResults(results: Bundle?) {
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrBlank()) submit(v, t)
            }
        })
        r.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        )
    }

    fun destroy() {
        hidePanel()
        recognizer?.destroy()
        recognizer = null
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
        scope.cancel()
    }
}
